#coding:utf-8

import sys
from PySide6.QtWidgets import *

from PySide6.QtWidgets import QApplication
from vg_editor import VisualGraphEditor
from vg_view import  QGraphicsView
from vg_node import GraphNode
from vg_node_port import NodePort,ExecPort

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        layout=QVBoxLayout()
        self.setLayout(layout)
        self.resize(800,800)
        self.show()

        self.view=QGraphicsView()
        self.scene=QGraphicsScene()
        self.scene.setSceneRect(-15000,-15000,30000,30000)
        self.view.setScene(self.scene)
        layout.addWidget(self.view)

        node=GraphNode(title="哈哈")
        self.item=node

        port=ExecPort()
        node.add_port(port)
        self.scene.addItem(self.item)




if __name__=="__main__":
    app=QApplication([])

    #window=MainWindow()  #用这个窗体就能显示node
    window=VisualGraphEditor() #用这个窗体无法显示node
    sys.exit(app.exec())
